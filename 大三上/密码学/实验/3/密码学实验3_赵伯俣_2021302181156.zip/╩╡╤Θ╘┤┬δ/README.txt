AES_encode    保存AES加密实现代码
PAD   保存短块处理相关代码
work_style 保存工作方式实现代码