attack.m测试嵌入水印图像被攻击后产生的所有图像的相关性并绘图
disp_xy.m 绘制单个SC图
output_disp.m绘制不同参数下的SC图
W_SVD_find.m计算相关性
S_SVD_get_waterCA.m计算原图加入水印后的小波低频系数
W_SVD_hide.m 水印嵌入