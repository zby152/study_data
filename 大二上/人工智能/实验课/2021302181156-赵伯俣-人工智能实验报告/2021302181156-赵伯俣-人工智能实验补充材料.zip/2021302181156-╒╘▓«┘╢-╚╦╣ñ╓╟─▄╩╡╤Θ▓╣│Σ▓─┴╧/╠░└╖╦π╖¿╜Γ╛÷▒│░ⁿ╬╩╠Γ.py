goods_number=int(input("请输入商品数量"))
goods=[]
for index in range(0,goods_number):
    goods_price=int(input("请输入商品价格:"))
    goods_wight=int(input("请输入商品重量"))
    goods.append((goods_price,goods_wight))

goods.sort(key=lambda x: x[0]/x[1],reverse=True) #按照商品价值进行降序排序
m = [0 for _ in range(goods_number)]  #m列表代表商品是否放入背包

def fractional_backpack(goods,w):  #w代表背包能承受的总重量

    total_v = 0  #总价格
    for i,(price,weight) in enumerate(goods):
        if w>= weight:
            m[i] = 1
            total_v += price
            w -= weight
        else:
            m[i] = w / weight
            total_v += m[i] * price
            w = 0
            break
    return total_v


print("选取的商品总价值为：")
print(fractional_backpack(goods,50))
print("选取的商品为：")
for index in range(0,goods_number):
    if(m[index]==1):
        print("选入全部")
        print(goods[index])
    elif(m[index]>0):
        print("选入")
        print(goods[index])
        print(m[index])
    else:
        print("不选入")
        print(goods[index])