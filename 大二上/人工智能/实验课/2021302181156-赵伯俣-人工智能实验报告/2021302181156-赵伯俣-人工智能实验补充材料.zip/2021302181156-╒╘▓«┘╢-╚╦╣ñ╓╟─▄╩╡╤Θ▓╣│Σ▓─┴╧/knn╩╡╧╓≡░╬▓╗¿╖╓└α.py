# sklearn库、matplotlib库与numpy库的调用
import sklearn.datasets as datasets
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import numpy as np
import operator

#打印数据集函数
def print_x_train():
    print("数据集（x_train）为:")
    print("序号  花萼长度  花萼宽度  花瓣长度  花瓣宽度")
    print(" ", end='')
    x = 1
    for a in x_train:
        print(x, end="     ")
        x += 1
        for b in a:
            print(b, end='     ')
        print('\n', end=' ')

#分析结果函数
def print_result():
    number = 0
    for index in range(0, len(y_true)):
        if y_pred[index] == y_true[index]:
            number += 1
    election_data = {'right': number, 'wrong': len(y_true) - number}
    candidate = [key for key in election_data]
    votes = [value for value in election_data.values()]
    plt.figure(figsize=(10, 10), dpi=100)
    plt.pie(votes, labels=candidate, autopct="%1.2f%%", colors=['c', 'm'],
            textprops={'fontsize': 24}, labeldistance=1.05)
    plt.legend(fontsize=16)
    plt.title(knn, fontsize=24)
    plt.show()
    print(knn)
    print('模型的分类结果:', y_pred)
    print('真实的分类结果:', y_true)
    b1=round(knn.score(x_test, y_test)*100,2)
    b2=f"{b1}%"
    print(b2)

#载入数据集并划分训练与测试集
iris = datasets.load_iris()
feature = iris['data']
target = iris['target']
x_train, x_test, y_train, y_test = train_test_split(feature, target, test_size=0.2, random_state=2022)#8：2划分数据集

print_x_train()

#定义k值并对比测试集的测试结果，根据准确率确定所选用的K值
knn = KNeighborsClassifier(n_neighbors=20)
train = knn.fit(x_train, y_train)
y_pred = knn.predict(x_test)
y_true = y_test

print_result()

#输入测试集进行测试
test1 = knn.predict([[6. ,3. ,4. ,3. ],
                     [6.2,3.8,4.2,5.4],
                     [3.1,2.8,4.9,4.3],
                     [8.9,5.6,4.8,10.2],
                     [4.4,3.0,1.3,0.2],
                     [5.7,3.8,1.9,0.5]])
print("输入的测试集预测类别为",test1)



